#jQuery Plugin exercise

* follow along with Flexslider documentation <http://www.woothemes.com/flexslider/> but put JS/CSS files in your own project folders
* show how to customize via config (eg. control nav, fade vs slide)
* show how to over-ride CSS in your own style sheet if necessary (don't edit flexslider.css)
* show smooth scroll hookup <https://github.com/kswedberg/jquery-smooth-scroll>
* change offset to show different config documentation
