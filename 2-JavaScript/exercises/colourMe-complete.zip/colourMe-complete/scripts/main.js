$(function() {
	$('h1').colourMe({
		color: "green"
	});
});