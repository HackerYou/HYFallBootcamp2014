$(function() {

  $('a').lightbox();

});