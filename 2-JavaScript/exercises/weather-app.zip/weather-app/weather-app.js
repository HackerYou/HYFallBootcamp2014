var weatherWidget = {
};

$(document).ready(function(){
  weatherWidget.init();
});