var App = {};
	App.cache = {};

	App.init = function() {
		$('html').removeClass('no-js');
	}

$(function(){
	App.init(); 
});