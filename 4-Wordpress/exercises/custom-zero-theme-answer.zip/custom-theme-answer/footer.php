    <!-- Footer Wrapper -->
      <div id="footer-wrapper">
        <footer id="footer" class="container">
          <div class="row">
            <div class="12u">
              <div id="copyright">
                &copy; <?php echo date('Y'); ?> <?php bloginfo( 'name' ); ?>. All rights reserved | Images: <a href="http://fotogrph.com/">fotogrph</a> | Design: <a href="http://html5up.net/">HTML5 UP</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
  <?php wp_footer(); ?>
  </body>
</html>