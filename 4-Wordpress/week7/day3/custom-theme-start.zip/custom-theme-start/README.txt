ZeroFour 2.5 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


A responsive blog/magazine site template design named as such because it's the fourth 
design up here (very creative I know). Has plenty of room for all sorts of content 
and even multilevel drop down menus.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33


Credits:

	Images:
		fotogrph (fotogrph.com)

	Icons
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)

	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		CSS3 Pie (css3pie.com)
		jquery.dropotron (n33.co)
		skelJS (skeljs.org)